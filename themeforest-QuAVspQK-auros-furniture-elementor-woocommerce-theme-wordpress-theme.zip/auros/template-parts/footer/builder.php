<div class="wrap">
    <div class="container">
        <?php auros_render_footer(); ?>
    </div>
</div>